"""Q4: Calculator using separate functions and if/elif/else"""


def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(a, b):
    return a * b


def divide(a, b):
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    return a / b


def modulus(a, b):
    if b == 0:
        raise ZeroDivisionError("Cannot calculate modulus by zero.")
    return a % b


def main():
    operations = {
        "+": add,
        "-": subtract,
        "*": multiply,
        "/": divide,
        "%": modulus,
    }

    while True:
        try:
            first = float(input("\\nEnter the first number: "))
            second = float(input("Enter the second number: "))
        except ValueError:
            print("Invalid input. Please enter numeric values.")
            continue

        operation = input("Choose operation (+, -, *, /, %): ").strip()

        if operation in operations:
            try:
                result = operations[operation](first, second)
                print(f"Result: {result:g}")
            except ZeroDivisionError as error:
                print(error)
        else:
            print("Invalid operation. Choose +, -, *, /, or %.")

        again = input("Would you like another calculation? (y/n): ").strip().lower()
        if again not in ("y", "yes"):
            print("Calculator closed.")
            break


if __name__ == "__main__":
    main()
