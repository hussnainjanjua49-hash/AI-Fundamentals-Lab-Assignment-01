# Fundamentals of AI — Lab Assignment 01

**Riphah International University, Sahiwal**  
**Course:** Lab of Fundamentals of AI

This repository contains Python solutions for all five questions in Lab Assignment 01.

## Contents

| File | Description |
| --- | --- |
| `q1_student_result.py` | Records 5 students, calculates totals/percentages/grades, finds the top student, and writes `results.txt`. |
| `q2_word_analysis.py` | Analyzes a sentence and writes the report to `word_analysis.txt`. |
| `q3_shopping_bill.py` | Records 5 products, calculates the bill and eligible 10% discount, and writes `bill.txt`. |
| `q4_calculator.py` | Interactive calculator for `+`, `-`, `*`, `/`, and `%`, using separate functions. |
| `q5_restaurant_order.py` | Restaurant menu, multiple-item ordering, bill calculation, and `orders.txt` output. |

## Requirements

- Python 3.8 or newer
- No third-party packages required

## How to run

Open a terminal in this folder and run one file at a time:

```bash
python q1_student_result.py
python q2_word_analysis.py
python q3_shopping_bill.py
python q4_calculator.py
python q5_restaurant_order.py
```

On some systems, use `python3` instead of `python`.

The text files are created in the current working directory when their corresponding programs run. The restaurant program appends each order to `orders.txt`.

## Concepts demonstrated

Variables, input/output, strings, lists, dictionaries, sets, loops, conditional statements, functions, arithmetic, and file handling.

## GitHub upload

1. Create a new repository on GitHub.
2. Upload the five `.py` files and this `README.md`, or push the folder using Git.
3. Do not upload generated result files unless you want to include sample output.

Example Git commands:

```bash
git init
git add .
git commit -m "Complete Fundamentals of AI Lab Assignment 01"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own repository URL.
