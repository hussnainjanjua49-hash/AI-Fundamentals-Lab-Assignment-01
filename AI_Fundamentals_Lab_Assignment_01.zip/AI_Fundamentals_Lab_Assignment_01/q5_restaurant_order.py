"""Q5: Restaurant Ordering and Billing System"""

MENU = {
    1: {"name": "Burger", "price": 500},
    2: {"name": "Pizza", "price": 800},
    3: {"name": "Fries", "price": 250},
    4: {"name": "Drink", "price": 150},
}


def calculate_bill(order):
    return sum(item["price"] * item["quantity"] for item in order.values())


def main():
    order = {}

    print("WELCOME TO THE RESTAURANT")
    print("=" * 35)

    while True:
        print("\\nMENU")
        for number, item in MENU.items():
            print(f"{number}. {item['name']} - Rs. {item['price']}")

        print("0. Finish order")
        choice = input("Select an item by number: ").strip()

        if choice == "0":
            break
        if not choice.isdigit() or int(choice) not in MENU:
            print("Invalid selection. Please choose 1-4 or 0.")
            continue

        item_number = int(choice)
        try:
            quantity = int(input("Enter quantity: "))
            if quantity <= 0:
                print("Quantity must be greater than zero.")
                continue
        except ValueError:
            print("Please enter a whole-number quantity.")
            continue

        item = MENU[item_number]
        if item_number in order:
            order[item_number]["quantity"] += quantity
        else:
            order[item_number] = {
                "name": item["name"],
                "price": item["price"],
                "quantity": quantity,
            }
        print(f"Added {quantity} x {item['name']}.")

    if not order:
        print("No items ordered.")
        report = "RESTAURANT BILL\\nNo items ordered.\\nTotal: Rs. 0"
    else:
        lines = ["RESTAURANT BILL", "=" * 35]
        for item in order.values():
            line_total = item["price"] * item["quantity"]
            lines.append(
                f"{item['name']}: Rs. {item['price']} x {item['quantity']} "
                f"= Rs. {line_total}"
            )
        lines.extend(["-" * 35, f"Final bill: Rs. {calculate_bill(order)}"])
        report = "\\n".join(lines)
        print("\\n" + report)

    with open("orders.txt", "a", encoding="utf-8") as file:
        file.write(report + "\\n" + "=" * 35 + "\\n")
    print("\\nOrder saved to orders.txt")


if __name__ == "__main__":
    main()
