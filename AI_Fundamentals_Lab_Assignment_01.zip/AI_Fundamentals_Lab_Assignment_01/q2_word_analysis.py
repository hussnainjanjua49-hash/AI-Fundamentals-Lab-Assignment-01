"""Q2: Sentence and Word Analysis"""


def analyze_sentence(sentence):
    words = sentence.split()
    unique_words = set(words)
    vowels = set("aeiou")
    vowel_count = sum(1 for character in sentence.lower() if character in vowels)

    if words:
        longest_word = max(words, key=len)
        shortest_word = min(words, key=len)
    else:
        longest_word = "(none)"
        shortest_word = "(none)"

    return {
        "sentence": sentence,
        "word_count": len(words),
        "character_count": len(sentence),
        "longest_word": longest_word,
        "shortest_word": shortest_word,
        "vowel_count": vowel_count,
        "unique_words": unique_words,
        "alphabetical_words": sorted(unique_words, key=str.lower),
    }


def main():
    sentence = input("Enter a sentence: ")
    result = analyze_sentence(sentence)

    lines = [
        "WORD ANALYSIS",
        "=" * 30,
        f"Sentence: {result['sentence']}",
        f"Total words: {result['word_count']}",
        f"Total characters (including spaces and punctuation): {result['character_count']}",
        f"Longest word: {result['longest_word']}",
        f"Shortest word: {result['shortest_word']}",
        f"Number of vowels: {result['vowel_count']}",
        f"Unique words: {', '.join(sorted(result['unique_words'], key=str.lower))}",
        f"Alphabetical order: {', '.join(result['alphabetical_words'])}",
    ]

    report = "\\n".join(lines)
    print("\\n" + report)

    with open("word_analysis.txt", "w", encoding="utf-8") as file:
        file.write(report + "\\n")
    print("\\nAnalysis saved to word_analysis.txt")


if __name__ == "__main__":
    main()
