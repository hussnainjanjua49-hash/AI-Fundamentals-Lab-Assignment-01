"""Q3: Shopping Bill Program"""


def calculate_bill(products):
    subtotal = sum(product["price"] * product["quantity"] for product in products)
    discount = subtotal * 0.10 if subtotal > 10000 else 0
    final_bill = subtotal - discount
    return subtotal, discount, final_bill


def main():
    products = []

    for index in range(5):
        print(f"\\n--- Product {index + 1} ---")
        name = input("Product name: ").strip()

        while True:
            try:
                price = float(input("Price in Rs.: "))
                if price >= 0:
                    break
                print("Price cannot be negative.")
            except ValueError:
                print("Please enter a valid number.")

        while True:
            try:
                quantity = int(input("Quantity: "))
                if quantity >= 0:
                    break
                print("Quantity cannot be negative.")
            except ValueError:
                print("Please enter a whole number.")

        products.append({
            "name": name,
            "price": price,
            "quantity": quantity,
            "total": price * quantity,
        })

    subtotal, discount, final_bill = calculate_bill(products)
    most_expensive = max(products, key=lambda product: product["price"])

    lines = ["SHOPPING BILL", "=" * 35]
    for product in products:
        lines.append(
            f"{product['name']}: Rs. {product['price']:.2f} x "
            f"{product['quantity']} = Rs. {product['total']:.2f}"
        )
    lines.extend([
        "-" * 35,
        f"Subtotal: Rs. {subtotal:.2f}",
        f"Discount: Rs. {discount:.2f}",
        f"Final bill: Rs. {final_bill:.2f}",
        f"Most expensive product (unit price): {most_expensive['name']} "
        f"(Rs. {most_expensive['price']:.2f})",
    ])

    report = "\\n".join(lines)
    print("\\n" + report)

    with open("bill.txt", "w", encoding="utf-8") as file:
        file.write(report + "\\n")
    print("\\nBill saved to bill.txt")


if __name__ == "__main__":
    main()
