"""Q1: Student Result Management System"""

SUBJECTS = ["Python", "Artificial Intelligence", "Mathematics"]
MAX_MARKS_PER_SUBJECT = 100


def calculate_result(marks):
    total = sum(marks.values())
    maximum = len(marks) * MAX_MARKS_PER_SUBJECT
    percentage = (total / maximum) * 100

    if percentage >= 80:
        grade = "A"
    elif percentage >= 70:
        grade = "B"
    elif percentage >= 60:
        grade = "C"
    elif percentage >= 50:
        grade = "D"
    else:
        grade = "F"

    return total, percentage, grade


def get_mark(subject):
    while True:
        try:
            mark = float(input(f"Enter marks in {subject} (0-100): "))
            if 0 <= mark <= 100:
                return mark
            print("Marks must be between 0 and 100.")
        except ValueError:
            print("Please enter a valid number.")


def main():
    students = []

    for index in range(5):
        print(f"\\n--- Enter details for student {index + 1} ---")
        name = input("Student name: ").strip()
        roll_number = input("Roll number: ").strip()
        marks = {subject: get_mark(subject) for subject in SUBJECTS}

        total, percentage, grade = calculate_result(marks)
        students.append({
            "name": name,
            "roll_number": roll_number,
            "marks": marks,
            "total": total,
            "percentage": percentage,
            "grade": grade,
        })

    report_lines = ["STUDENT RESULT MANAGEMENT SYSTEM", "=" * 40]
    for student in students:
        report_lines.extend([
            f"Name: {student['name']}",
            f"Roll number: {student['roll_number']}",
            *(f"{subject}: {mark:g}" for subject, mark in student["marks"].items()),
            f"Total: {student['total']:g}/300",
            f"Percentage: {student['percentage']:.2f}%",
            f"Grade: {student['grade']}",
            "-" * 40,
        ])

    top_student = max(students, key=lambda student: student["percentage"])
    report_lines.extend([
        "TOP-PERFORMING STUDENT",
        f"Name: {top_student['name']}",
        f"Roll number: {top_student['roll_number']}",
        f"Percentage: {top_student['percentage']:.2f}%",
    ])

    report = "\\n".join(report_lines)
    print("\\n" + report)

    with open("results.txt", "w", encoding="utf-8") as file:
        file.write(report + "\\n")
    print("\\nResults saved to results.txt")


if __name__ == "__main__":
    main()
